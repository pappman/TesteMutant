var sContIngredientes; 

function GeId(sElemento){
	return document.getElementById(sElemento);
}

function DiOb(sElemento,sBool){
	GeId(sElemento).style.display=sBool==0?'none':'block';
}

function TxtVazio(sTextBox){
	var sCont,sRetorno=true;
	
	for (sCont=0;sCont<sTextBox.length;sCont++){
		if(sTextBox.charCodeAt(sCont)!=32 && sTextBox.charCodeAt(sCont)!=13 && sTextBox.charCodeAt(sCont)!=10){
			sRetorno=false;
			break;
		}
	}
	
	return sRetorno;
}

function EnvML(){
	var sIngredientes, sCont, sParametros;
	
	if(TxtVazio(GeId('txtNome').value)){
		alert('O NOME DO CLIENTE deve ser preenchido.');
		GeId('txtNome').focus();
		return;
	}
	else if(GeId("slcLanche").value==0){
		alert('O LANCHE deve ser selecionado.');
		document.slcLanche.focus();
		return;
	}
	
	sIngredientes = ""
	
	for (sCont=1;sCont<sContIngredientes;sCont++){
		if(GeId('chkAdicional'+sCont).checked==true && GeId('slcAdicional'+sCont).value > 0){
			sIngredientes += '.'+sCont+'-'+GeId('slcAdicional'+sCont).value;			
		}
	}
	if(sIngredientes!=''){
		sIngredientes = sIngredientes.substring(1);
	}
	
	if(GeId("slcLanche").options[GeId("slcLanche").selectedIndex].text=='Personalizado' && sIngredientes==''){
		alert('Para o lanche PERSONALIZADO é necessário selecionar ao menos um ingrediente adicional.');
		return;
	}
	
	sParametros = '?id='+escape(GeId('txtIdPedido').value)+'&nm='+escape(GeId('txtNome').value)+'&lc='+escape(GeId('slcLanche').value)+'&ad='+sIngredientes;	
	window.location = '/EnviarPedido.asp'+sParametros;
}
