/*--------------------------------------------------------------------------------
Procedure: stp_BuscaLanches
Objetivo: Retorna registros cadastrados na tabela Lanches.
Data de Cria��o: 16/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_BuscaLanches 
AS
BEGIN
	SELECT * 
	FROM Lanches
	ORDER BY
	IIf(ID_Lanche = 1, 0, 1),
	Descricao_Lanche
END
-- Fim da Procedure