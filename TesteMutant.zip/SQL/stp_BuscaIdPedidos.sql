/*--------------------------------------------------------------------------------
Procedure: stp_BuscaIdPedidos
Objetivo: Retorna �ltimo ID dos pedidos.
Data de Cria��o: 16/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_BuscaIdPedidos
AS
BEGIN
	SELECT (ISNULL(MAX(ID_Pedido) , 0) + 1) ID_Pedido
	FROM Pedidos
END
-- Fim da Procedure