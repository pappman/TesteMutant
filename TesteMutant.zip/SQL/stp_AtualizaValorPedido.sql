/*--------------------------------------------------------------------------------
Procedure: stp_AtualizaValorPedido
Objetivo: Atualiza o valor do pedido.
Data de Cria��o: 18/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_AtualizaValorPedido 
@IDPedido AS INT,
@ValorPedido AS MONEY,
@ValorPedidoDesconto AS MONEY

AS
BEGIN
	-------------------------------
	--- Atualiza Tabela Pedidos ---
	-------------------------------
	
	UPDATE Pedidos 
	   SET Valor_Pedido = @ValorPedido,
		   Valor_Pedido_Desconto = @ValorPedidoDesconto
	 WHERE ID_Pedido = @IDPedido
END
-- Fim da Procedure