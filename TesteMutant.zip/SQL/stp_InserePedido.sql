/*--------------------------------------------------------------------------------
Procedure: stp_InserePedido
Objetivo: Registra os pedidos recebidos.
Data de Cria��o: 18/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_InserePedido 
@IDPedido AS INT,
@NomeCliente AS VARCHAR(100),
@IDLanche AS INT

AS
BEGIN
	-------------------------------
	--- Alimenta Tabela Pedidos ---
	-------------------------------

	INSERT INTO Pedidos(
		ID_Pedido,
		Data_Pedido,
		Nome_Cliente,
		ID_Lanche
	)VALUES(
		@IDPedido,
		GETDATE(),
		@NomeCliente,
		@IDLanche
	)
END
-- Fim da Procedure