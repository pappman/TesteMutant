/*--------------------------------------------------------------------------------
Procedure: stp_BuscaIngredientes
Objetivo: Retorna registros cadastrados na tabela Ingredientes.
Data de Cria��o: 16/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_BuscaIngredientes 
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @Cont_Regs AS INT

	SELECT @Cont_Regs = COUNT(ID_Ingrediente) FROM Ingredientes

	SELECT @Cont_Regs Registros, *
	FROM Ingredientes
	ORDER BY
	Descricao_Ingrediente
END
-- Fim da Procedure