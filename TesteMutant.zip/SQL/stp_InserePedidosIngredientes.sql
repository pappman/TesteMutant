/*--------------------------------------------------------------------------------
Procedure: stp_InserePedidosIngredientes 
Objetivo: Registra os pedidos / ingredientes.
Data de Cria��o: 18/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_InserePedidosIngredientes 
@IDPedido AS INT,
@IDIngrediente AS INT,
@Qtd AS INT

AS
BEGIN
	-------------------------------
	--- Alimenta Tabela Pedidos ---
	-------------------------------

	INSERT INTO Pedidos_Ingredientes(
		ID_Pedido,
		ID_Ingrediente,
		Qtd
	)VALUES(
		@IDPedido,
		@IDIngrediente,
		@Qtd
	)
END
-- Fim da Procedure