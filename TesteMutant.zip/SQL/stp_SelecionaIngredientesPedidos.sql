/*--------------------------------------------------------------------------------
Procedure: stp_SelecionaIngredientesPedidos
Objetivo: Retorna registros cadastrados na tabela Pedidos_Ingredientes.
Data de Cria��o: 18/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_SelecionaIngredientesPedidos 
@IDPedido AS INT

AS
BEGIN
	SET NOCOUNT ON

	SELECT DISTINCT *
	  FROM Pedidos_Ingredientes P_I
	  JOIN Ingredientes I ON P_I.ID_Ingrediente = I.ID_Ingrediente
	 WHERE ID_Pedido = @IDPedido
END
-- Fim da Procedure