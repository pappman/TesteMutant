/*--------------------------------------------------------------------------------
Procedure: stp_SelecionaIngredientesLanches
Objetivo: Retorna registros cadastrados na tabela Lanches_Ingredientes.
Data de Cria��o: 18/08/2020												
Autor: Rafael Rodrigues Silva											
--------------------------------------------------------------------------------*/
CREATE OR ALTER PROCEDURE stp_SelecionaIngredientesLanches 
@IDLanche AS INT

AS
BEGIN
	SET NOCOUNT ON

	SELECT *
	FROM Lanches_Ingredientes
	WHERE ID_Lanche = @IDLanche
END
-- Fim da Procedure