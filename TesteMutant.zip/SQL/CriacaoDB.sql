---------------
--- Cria DB ---
---------------

IF NOT EXISTS (SELECT * FROM sys.databases WHERE NAME = 'Mutant')
	CREATE DATABASE Mutant
GO

USE Mutant
GO

----------------------
--- Exclui Tabelas ---
----------------------

-- Exclui tabelas casos existam
IF OBJECT_ID('dbo.Pedidos_Ingredientes') IS NOT NULL
	DROP TABLE Pedidos_Ingredientes

IF OBJECT_ID('dbo.Lanches_Ingredientes') IS NOT NULL
	DROP TABLE Lanches_Ingredientes

IF OBJECT_ID('dbo.Pedidos') IS NOT NULL
	DROP TABLE Pedidos

IF OBJECT_ID('dbo.Ingredientes') IS NOT NULL
	DROP TABLE Ingredientes

IF OBJECT_ID('dbo.Lanches') IS NOT NULL
	DROP TABLE Lanches	

IF OBJECT_ID('dbo.Promocoes') IS NOT NULL
	DROP TABLE Promocoes

GO

--------------------
--- Cria Tabelas ---
--------------------

-- Cria Tabela Ingredientes
CREATE TABLE Ingredientes
(
	ID_Ingrediente INT NOT NULL PRIMARY KEY,
	Descricao_Ingrediente VARCHAR(50) NOT NULL,
	Valor_Ingrediente MONEY
)
	
-- Cria Tabela Lanches
CREATE TABLE Lanches
(
	ID_Lanche INT NOT NULL PRIMARY KEY,
	Descricao_Lanche VARCHAR(50) NOT NULL
)
GO

-- Cria Tabela Lanches_Ingredientes
CREATE TABLE Lanches_Ingredientes
(
	ID_Lanche INT NOT NULL,
	ID_Ingrediente INT NOT NULL
	FOREIGN KEY (ID_Lanche) REFERENCES Lanches(ID_Lanche),
	FOREIGN KEY (ID_Ingrediente) REFERENCES Ingredientes(ID_Ingrediente)
)

-- Cria Tabela Pedidos
CREATE TABLE Pedidos
(
	ID_Pedido INT NOT NULL PRIMARY KEY,
	Data_Pedido DATE NOT NULL,
	Nome_Cliente VARCHAR(100) NOT NULL,
	ID_Lanche INT NOT NULL,
	Valor_Pedido MONEY NULL,
	Valor_Pedido_Desconto MONEY NULL,
	FOREIGN KEY (ID_Lanche) REFERENCES Lanches(ID_Lanche)
)
GO

-- Cria Tabela Pedidos_Ingredientes
CREATE TABLE Pedidos_Ingredientes
(
	ID_Pedido INT NOT NULL,
	ID_Ingrediente INT NOT NULL,
	Qtd INT NOT NULL,
	FOREIGN KEY (ID_Pedido) REFERENCES Pedidos(ID_Pedido),
	FOREIGN KEY (ID_Ingrediente) REFERENCES Ingredientes(ID_Ingrediente)
)

-- Cria Tabela Promocoes
CREATE TABLE Promocoes
(
	ID_Promocao INT NOT NULL PRIMARY KEY,
	Descricao_Promocao VARCHAR(50) NOT NULL
)
GO

------------------------
--- Alimenta Tabelas ---
------------------------

-- Tabela Ingredientes
INSERT INTO Ingredientes VALUES
(1, 'Alface', 0.4),
(2, 'Bacon', 2),
(3, 'Hamb�rguer de Carne', 3),
(4, 'Ovo', 0.8),
(5, 'Queijo', 1.5)
	
-- Tabela Lanches
INSERT INTO Lanches VALUES
(1, 'Personalizado'),
(2, 'X-Bacon'),
(3, 'X-Burger'),
(4, 'X-Egg'),
(5, 'X-Egg Bacon')

-- Tabela Lanches_Ingredientes
INSERT INTO Lanches_Ingredientes VALUES
(2, 2),
(2, 3),
(2, 5),
(3, 3),
(3, 5),
(4, 4),
(4, 3),
(4, 5),
(5, 4),
(5, 2),
(5, 3),
(5, 5)
	
-- Tabela Promocoes
INSERT INTO Promocoes VALUES
(1, 'Light'),
(2, 'Muita Carne'),
(3, 'Muito Queijo')
GO